#ifndef DB_H_
#define DB_H_

extern int db( void );

#endif
