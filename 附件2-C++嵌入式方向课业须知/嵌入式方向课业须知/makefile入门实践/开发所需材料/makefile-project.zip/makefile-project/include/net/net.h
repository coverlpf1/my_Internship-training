#ifndef NET_H_
#define NET_H_

extern int
net();

#endif
