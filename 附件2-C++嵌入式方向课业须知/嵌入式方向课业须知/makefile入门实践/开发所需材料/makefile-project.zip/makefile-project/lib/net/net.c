#include <net/net.h>
#include <stdio.h>
int
net()
{
  printf("net\n");
  return 0;
}
