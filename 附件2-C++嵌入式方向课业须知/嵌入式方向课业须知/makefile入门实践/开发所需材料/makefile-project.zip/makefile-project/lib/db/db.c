#include <db/db.h>
#include <stdio.h>

int
db()
{
  printf("db\n");
  return 0;
}
