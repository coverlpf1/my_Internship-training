#include <server/server.h>
#include <ui/ui.h>
#include <stdio.h>

int
main( int argc, char ** argv )
{
  ui();
  printf("server\n");
  return 0;
}
